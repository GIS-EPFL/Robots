this folder must be place next to folders: 
"abb_experimental"
"COMPAS_ABB6700_IRBT"

that are for example located:
C:\IBOIS57\_Code\Software

